//
//  main.m
//  MDSGeocoderViewController
//
//  Created by Ryan Johnson on 4/16/12.
//  Copyright (c) 2012 mobile data solutions. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MDSAppDelegate.h"

int main(int argc, char *argv[])
{
  @autoreleasepool {
      return UIApplicationMain(argc, argv, nil, NSStringFromClass([MDSAppDelegate class]));
  }
}
